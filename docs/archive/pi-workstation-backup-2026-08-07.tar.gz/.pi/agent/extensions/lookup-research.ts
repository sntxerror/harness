/**
 * Gemini Search extension — lookup + research with configurable levels
 *
 * Registers 4 tools for live/fresh info via Gemini with Google Search grounding:
 *   - quick_lookup  : tiny factual data (dates, names, versions)
 *   - lookup        : fact-check / verification
 *   - research      : complex topics, comparisons, how-tos
 *   - deep_research : exhaustive analysis with thorough reasoning
 *
 * All levels are configurable in ~/.pi/agent/settings.json under "lookup-research":
 *
 * {
 *   "lookup-research": {
 *     "levels": {
 *       "quick-lookup":   { "model": "...", "maxInputChars": 150,  "maxOutputTokens": 40,   "thinkingLevel": "MEDIUM" },
 *       "lookup":         { "model": "...", "maxInputChars": 150,  "maxOutputTokens": 250,  "thinkingLevel": "MEDIUM" },
 *       "research":       { "model": "...", "maxInputChars": 300,  "maxOutputTokens": 2000, "thinkingLevel": "HIGH" },
 *       "deep-research":  { "model": "...", "maxInputChars": 300,  "maxOutputTokens": 5000, "thinkingLevel": "HIGH" }
 *     }
 *   }
 * }
 *
 * API key resolution order:
 *   1. GEMINI_API_KEY env var
 *   2. ./.pi/auth.json -> { "gemini": { "key": "..." } }
 *   3. ~/.pi/agent/auth.json -> { "gemini": { "key": "..." } }
 */

import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { homedir } from "node:os";
import { join, resolve } from "node:path";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Text } from "@earendil-works/pi-tui";
import { Type } from "typebox";

// ── Types ───────────────────────────────────────────────────────────────

interface LevelConfig {
  model: string;
  maxInputChars: number;
  maxOutputTokens: number;
  thinkingLevel: string;
}

interface LevelsConfig {
  "quick-lookup": LevelConfig;
  lookup: LevelConfig;
  research: LevelConfig;
  "deep-research": LevelConfig;
}

type Depth = "quick-lookup" | "lookup" | "research" | "deep-research";

interface UsageDB {
  count: number;
  year: number;
  month: number;
  dailyCount: number;
  lastDate: number;
}

interface UsageStats {
  promptTokens: number;
  candidatesTokens: number;
  thoughtsTokens: number;
  totalTokens: number;
  queriesUsed: number;
  queriesRemaining: number;
  dailyCount: number;
}

interface GeminiResponse {
  candidates?: Array<{
    content?: { parts?: Array<{ text?: string }> };
    groundingMetadata?: {
      webSearchQueries?: string[];
      groundingChunks?: Array<{ web?: { uri?: string; title?: string } }>;
    };
  }>;
  error?: { message?: string };
  usageMetadata?: {
    promptTokenCount?: number;
    candidatesTokenCount?: number;
    thoughtsTokenCount?: number;
    totalTokenCount?: number;
  };
}

// ── Defaults (overridable via settings.json) ────────────────────────────

const DEFAULT_LEVELS: LevelsConfig = {
  "quick-lookup": {
    model: "gemini-3.1-flash-lite",
    maxInputChars: 150,
    maxOutputTokens: 40,
    thinkingLevel: "MEDIUM",
  },
  lookup: {
    model: "gemini-3.1-flash-lite",
    maxInputChars: 150,
    maxOutputTokens: 250,
    thinkingLevel: "MEDIUM",
  },
  research: {
    model: "gemini-3.5-flash",
    maxInputChars: 300,
    maxOutputTokens: 2000,
    thinkingLevel: "MEDIUM",
  },
  "deep-research": {
    model: "gemini-3.5-flash",
    maxInputChars: 300,
    maxOutputTokens: 5000,
    thinkingLevel: "HIGH",
  },
};

// ── Constants ───────────────────────────────────────────────────────────

const SETTINGS_PATH = join(homedir(), ".pi", "agent", "settings.json");
const COUNTER_PATH = join(homedir(), ".pi", "agent", "search_counter.json");
const FREE_MONTHLY_LIMIT = 5000;
const DEFAULT_DAILY_LIMIT = 100;
const MAX_SOURCES = 6;
const RETRYABLE_STATUS = new Set([429, 500, 502, 503, 504]);
const MAX_RETRIES = 3;
const MAX_BACKOFF_MS = 16_000;
const MAX_RETRY_AFTER_MS = 60_000;

const GEMINI_ENDPOINT = (model: string) =>
  `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;

const SYSTEM_INSTRUCTION = `You are a web research assistant with live internet access via two tools: google_search (web search) and url_context (fetch & read specific URLs the user gives you).
RULES:
- ALWAYS ground your answer using these tools. Never answer from memory alone.
- State facts directly. Do not add filler, disclaimers, or conversational preamble.`;

// ── System prompts per depth ────────────────────────────────────────────

const DEPTH_PROMPTS: Record<Depth, string> = {
  "quick-lookup":
    "This is a QUICK LOOKUP query for a small factual answer (date, name, version number, etc.). Answer in ONE sentence only.",
  lookup:
    "This is a VERIFICATION / FACT-CHECK query. Answer concisely in 1-3 sentences. Only include essential facts.",
  research:
    "This is a COMPLEX research query. Provide a thorough, well-structured answer covering the key facets. Use short sections or bullet points where helpful.",
  "deep-research":
    "This is a DEEP research query. Provide an exhaustive, deeply analytical answer. Cover all important facets, consider multiple perspectives, include nuanced analysis, and structure with clear sections. Prioritize thoroughness and insight over brevity.",
};

// ── Timeouts per depth ──────────────────────────────────────────────────

const DEPTH_TIMEOUTS: Record<Depth, { flex: number; standard: number }> = {
  "quick-lookup": { flex: 120_000, standard: 120_000 },
  lookup: { flex: 120_000, standard: 120_000 },
  research: { flex: 300_000, standard: 300_000 },
  "deep-research": { flex: 300_000, standard: 600_000 },
};

// ── Config loader ───────────────────────────────────────────────────────

let cachedLevels: LevelsConfig | null = null;

function loadLevels(): LevelsConfig {
  if (cachedLevels) return cachedLevels;

  try {
    const settings = JSON.parse(readFileSync(SETTINGS_PATH, "utf-8"));
    const cfg = settings?.["lookup-research"]?.levels;
    if (cfg && typeof cfg === "object") {
      const merged = { ...DEFAULT_LEVELS };
      for (const key of Object.keys(DEFAULT_LEVELS) as Depth[]) {
        if (cfg[key] && typeof cfg[key] === "object") {
          merged[key] = {
            model:
              typeof cfg[key].model === "string"
                ? cfg[key].model
                : DEFAULT_LEVELS[key].model,
            maxInputChars:
              typeof cfg[key].maxInputChars === "number"
                ? cfg[key].maxInputChars
                : DEFAULT_LEVELS[key].maxInputChars,
            maxOutputTokens:
              typeof cfg[key].maxOutputTokens === "number"
                ? cfg[key].maxOutputTokens
                : DEFAULT_LEVELS[key].maxOutputTokens,
            thinkingLevel:
              typeof cfg[key].thinkingLevel === "string"
                ? cfg[key].thinkingLevel
                : DEFAULT_LEVELS[key].thinkingLevel,
          };
        }
      }
      cachedLevels = merged;
      return merged;
    }
  } catch {
    /* ignore */
  }
  cachedLevels = DEFAULT_LEVELS;
  return DEFAULT_LEVELS;
}

function levelFor(depth: Depth): LevelConfig {
  return loadLevels()[depth];
}

// ── Usage tracking ──────────────────────────────────────────────────────

function loadUsageDB(): UsageDB {
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth();
  const currentDate = now.getDate();

  let db: UsageDB = {
    count: 0,
    year: currentYear,
    month: currentMonth,
    dailyCount: 0,
    lastDate: currentDate,
  };

  if (existsSync(COUNTER_PATH)) {
    try {
      const parsed = JSON.parse(
        readFileSync(COUNTER_PATH, "utf-8"),
      ) as Partial<UsageDB>;
      if (parsed) {
        const sameMonth =
          parsed.year === currentYear && parsed.month === currentMonth;
        if (sameMonth) db.count = parsed.count ?? 0;
        if (sameMonth && parsed.lastDate === currentDate) {
          db.dailyCount = parsed.dailyCount ?? 0;
        }
      }
    } catch {
      /* ignore */
    }
  }
  return db;
}

function isLimitExceeded(): { exceeded: boolean; reason: string } {
  const db = loadUsageDB();
  if (db.dailyCount >= DEFAULT_DAILY_LIMIT) {
    return {
      exceeded: true,
      reason: `daily limit (${DEFAULT_DAILY_LIMIT}/day)`,
    };
  }
  if (db.count >= FREE_MONTHLY_LIMIT) {
    return {
      exceeded: true,
      reason: `monthly limit (${FREE_MONTHLY_LIMIT}/month)`,
    };
  }
  return { exceeded: false, reason: "" };
}

function updateAndGetUsage(
  queriesExecuted: number,
  metadata: any,
): UsageDB & UsageStats {
  const db = loadUsageDB();
  db.count += queriesExecuted;
  db.dailyCount += queriesExecuted;
  db.lastDate = new Date().getDate();

  try {
    writeFileSync(COUNTER_PATH, JSON.stringify(db), "utf-8");
  } catch {}

  return {
    ...db,
    promptTokens: metadata?.promptTokenCount ?? 0,
    candidatesTokens: metadata?.candidatesTokenCount ?? 0,
    thoughtsTokens: metadata?.thoughtsTokenCount ?? 0,
    totalTokens: metadata?.totalTokenCount ?? 0,
    queriesUsed: queriesExecuted,
    queriesRemaining: Math.max(0, FREE_MONTHLY_LIMIT - db.count),
  };
}

// ── API key resolution ──────────────────────────────────────────────────

function resolveApiKey(): string {
  const fromEnv = process.env["GEMINI_API_KEY"];
  if (fromEnv) return fromEnv;

  try {
    const projectAuth = resolve(process.cwd(), ".pi", "auth.json");
    const auth = JSON.parse(readFileSync(projectAuth, "utf-8"));
    const key = auth.gemini?.key;
    if (key) return key;
  } catch {}

  try {
    const globalAuth = join(homedir(), ".pi", "agent", "auth.json");
    const auth = JSON.parse(readFileSync(globalAuth, "utf-8"));
    const key = auth.gemini?.key;
    if (key) return key;
  } catch {}

  throw new Error("Gemini API key not found.");
}

// ── URL helpers ─────────────────────────────────────────────────────────

async function resolveUrl(url: string, signal: AbortSignal): Promise<string> {
  if (!url.includes("vertexaisearch.cloud.google.com")) return url;
  try {
    const res = await fetch(url, { method: "GET", redirect: "manual", signal });
    const loc = res.headers.get("location");
    if (loc) return loc;
  } catch {}
  return url;
}

function hostOf(url: string): string {
  try {
    return new URL(url).host.replace(/^www\./, "");
  } catch {
    return "";
  }
}

// ── Core search ─────────────────────────────────────────────────────────

async function runSearch(
  query: string,
  depth: Depth,
  signal: AbortSignal,
  onUpdate?: (update: {
    content: Array<{ type: string; text: string }>;
  }) => void,
): Promise<{
  answer: string;
  sources: string[];
  sourceCount: number;
  groundingQueries: string[];
  promptTokens: number;
  candidatesTokens: number;
  thoughtsTokens: number;
  totalTokens: number;
  queriesUsed: number;
  queriesRemaining: number;
  dailyCount: number;
  durationMs: number;
}> {
  const apiKey = resolveApiKey();
  const level = levelFor(depth);
  const startTime = Date.now();

  // Truncate input to configured character limit
  let cleanQuery = query.trim();
  if (cleanQuery.length > level.maxInputChars) {
    cleanQuery = cleanQuery.substring(0, level.maxInputChars);
  }

  const instruction = `${SYSTEM_INSTRUCTION}\n${DEPTH_PROMPTS[depth]}`;
  const model = level.model;
  const timeouts = DEPTH_TIMEOUTS[depth];

  const buildBody = (serviceTier: "flex" | "standard") => {
    const body: any = {
      system_instruction: { parts: [{ text: instruction }] },
      contents: [{ parts: [{ text: cleanQuery }] }],
      tools: [{ google_search: {} }, { url_context: {} }],
      service_tier: serviceTier,
      generationConfig: {
        temperature: 0.2,
        maxOutputTokens: level.maxOutputTokens,
      },
    };

    if (
      level.thinkingLevel &&
      level.thinkingLevel !== "THINKING_LEVEL_UNSPECIFIED"
    ) {
      body.generationConfig.thinkingConfig = {
        thinkingLevel: level.thinkingLevel,
      };
    }

    return body;
  };

  const doFetch = async (
    serviceTier: "flex" | "standard",
    timeoutMs: number,
  ): Promise<Response> => {
    const timeoutSignal = AbortSignal.timeout(timeoutMs);
    const combined =
      "any" in AbortSignal
        ? AbortSignal.any([signal, timeoutSignal])
        : timeoutSignal;
    return fetch(GEMINI_ENDPOINT(model), {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-goog-api-key": apiKey },
      body: JSON.stringify(buildBody(serviceTier)),
      signal: combined,
    });
  };

  const sleep = (ms: number): Promise<void> =>
    new Promise((resolve, reject) => {
      const t = setTimeout(resolve, ms);
      signal.addEventListener(
        "abort",
        () => {
          clearTimeout(t);
          reject(new Error("aborted"));
        },
        { once: true },
      );
    });

  const parseRetryAfter = (header: string | null): number | undefined => {
    if (!header) return undefined;
    const secs = Number(header);
    if (Number.isFinite(secs)) return secs * 1000;
    return undefined;
  };

  const backoffDelay = (attempt: number, retryAfterMs?: number): number => {
    if (retryAfterMs !== undefined)
      return Math.min(retryAfterMs, MAX_RETRY_AFTER_MS);
    return Math.min(1000 * 2 ** attempt, MAX_BACKOFF_MS) + Math.random() * 500;
  };

  const fetchWithRetry = async (
    serviceTier: "flex" | "standard",
    timeoutMs: number,
  ): Promise<Response> => {
    let lastResponse: Response | undefined;
    let lastError: unknown;
    for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
      if (signal.aborted) throw new Error("aborted");
      try {
        const res = await doFetch(serviceTier, timeoutMs);
        if (res.ok || !RETRYABLE_STATUS.has(res.status)) return res;
        lastResponse = res;
      } catch (err) {
        if (signal.aborted) throw err;
        lastError = err;
      }
      if (attempt < MAX_RETRIES) {
        const retryAfterMs = parseRetryAfter(
          lastResponse?.headers.get("retry-after") ?? null,
        );
        await sleep(backoffDelay(attempt, retryAfterMs));
      }
    }
    if (lastResponse) return lastResponse;
    throw lastError;
  };

  let response: Response;
  try {
    response = await fetchWithRetry("flex", timeouts.flex);
    onUpdate?.({
      content: [
        { type: "text", text: `🔎 Processing response from ${model}...` },
      ],
    });
  } catch (err) {
    if (signal.aborted) throw err;
    response = await fetchWithRetry("standard", timeouts.standard);
  }

  if (!response.ok && RETRYABLE_STATUS.has(response.status)) {
    response = await fetchWithRetry("standard", timeouts.standard);
  }

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Gemini API error (${response.status}): ${errText}`);
  }

  const data = (await response.json()) as GeminiResponse;
  if (data.error)
    throw new Error(`Gemini API error: ${data.error.message ?? "unknown"}`);

  const candidate = data.candidates?.[0];
  const answer =
    candidate?.content?.parts
      ?.map((p) => p.text ?? "")
      .join("\n")
      .trim() ?? "(no answer returned)";

  const chunks = candidate?.groundingMetadata?.groundingChunks ?? [];
  const rawUrls = chunks
    .map((c) => c.web?.uri)
    .filter((u): u is string => !!u)
    .slice(0, MAX_SOURCES);

  if (rawUrls.length > 0) {
    onUpdate?.({
      content: [
        {
          type: "text",
          text: `📎 Resolving ${rawUrls.length} source${rawUrls.length > 1 ? "s" : ""}...`,
        },
      ],
    });
  }

  const resolved = await Promise.all(rawUrls.map((u) => resolveUrl(u, signal)));

  const seen = new Set<string>();
  const sources: string[] = [];
  for (const u of resolved) {
    if (seen.has(u)) continue;
    seen.add(u);
    const host = hostOf(u);
    sources.push(`${sources.length + 1}. ${host ? host + " — " : ""}${u}`);
  }

  let answerText =
    sources.length > 0
      ? `${answer}\n\nSources:\n${sources.join("\n")}`
      : answer;

  const groundingQueries = candidate?.groundingMetadata?.webSearchQueries ?? [];
  const usage = updateAndGetUsage(groundingQueries.length, data.usageMetadata);
  const durationMs = Date.now() - startTime;

  return {
    answer: answerText,
    sources,
    sourceCount: sources.length,
    groundingQueries,
    promptTokens: usage.promptTokens,
    candidatesTokens: usage.candidatesTokens,
    thoughtsTokens: usage.thoughtsTokens,
    totalTokens: usage.totalTokens,
    queriesUsed: usage.queriesUsed,
    queriesRemaining: usage.queriesRemaining,
    dailyCount: usage.dailyCount,
    durationMs,
  };
}

// ── Helpers ─────────────────────────────────────────────────────────────

interface ToolDef {
  name: string;
  label: string;
  description: string;
  queryDescription: string;
  depth: Depth;
}

const TOOLS: ToolDef[] = [
  {
    name: "quick_lookup",
    label: "Quick Lookup",
    description:
      "CRITICAL RULE: Pass a maximum of 1-3 keywords for tiny factual queries. " +
      "Pure search terms only. Use for dates, version numbers, library names, single facts. " +
      "DO NOT pass chat text, system parameters, context files, or conversational history.",
    queryDescription: "The bare factual query (date, name, version, flag).",
    depth: "quick-lookup",
  },
  {
    name: "lookup",
    label: "Lookup",
    description:
      "CRITICAL RULE: Pass a maximum of 3-6 keywords. Pure search terms only. " +
      "DO NOT pass chat text, system parameters, context files, or conversational history block strings here. " +
      "Use for fact-checking, verification, or quick second opinions.",
    queryDescription: "The raw lean query string to research.",
    depth: "lookup",
  },
  {
    name: "research",
    label: "Research",
    description:
      "CRITICAL RULE: Pass a clean, singular topic query string. " +
      "DO NOT pack contextual conversations, project logs, or full repository file dumps here. " +
      "Use for multi-faceted topics, how-tos, comparisons, or architecture opinions.",
    queryDescription: "The specific multi-faceted search question.",
    depth: "research",
  },
  {
    name: "deep_research",
    label: "Deep Research",
    description:
      "CRITICAL RULE: Pass a clean, singular topic query string. " +
      "DO NOT pack contextual conversations, project logs, or full repository file dumps here. " +
      "Use for exhaustive, deeply analytical research requiring thorough coverage and nuanced insights.",
    queryDescription: "The specific topic to exhaustively investigate.",
    depth: "deep-research",
  },
];

// ── Extension entry point ───────────────────────────────────────────────

export default function (pi: ExtensionAPI) {
  for (const tool of TOOLS) {
    pi.registerTool({
      name: tool.name,
      label: tool.label,
      description: tool.description,
      parameters: Type.Object({
        query: Type.String({ description: tool.queryDescription }),
      }),

      // ── Render: tool call header — full query, multiline if needed ──
      renderCall(args, theme, _context) {
        const out = new Text(
          theme.fg("toolTitle", theme.bold(`${tool.name}: `)) +
            theme.fg("accent", args.query),
          0,
          0,
        );
        return out;
      },

      // ── Render: tool result — preview with footer always visible, expand for full text ──
      renderResult(result, { expanded, isPartial }, theme, _context) {
        if (isPartial) {
          return new Text(theme.fg("warning", "Searching..."), 0, 0);
        }

        const details = result.details as Record<string, any> | undefined;
        const isErr =
          result.isError ||
          (typeof details?.isError === "boolean" && details.isError);

        if (isErr) {
          const content = result.content[0];
          const msg =
            content?.type === "text"
              ? content.text.split("\n")[0].slice(0, 120)
              : "Error";
          return new Text(theme.fg("error", msg), 0, 0);
        }

        const content = result.content[0];
        const text = content?.type === "text" ? content.text : "";
        const lines = text.split("\n");
        const isLong = lines.length > 8 || text.length > 400;

        // Preview: first few lines when collapsed
        let displayText: string;
        if (!expanded && isLong) {
          const previewLines = lines.slice(0, 5);
          displayText = previewLines.join("\n");
          if (lines.length > 5) {
            displayText +=
              "\n" +
              theme.fg(
                "muted",
                `... ${lines.length - 5} more lines (ctrl+o to expand)`,
              );
          }
        } else {
          displayText = text;
        }

        // Compact footer
        const separator = "─".repeat(80);
        const durSec =
          details?.durationMs != null
            ? `${(details.durationMs / 1000).toFixed(1)}s`
            : "";
        const footer = [
          theme.fg("dim", separator),
          theme.fg(
            "dim",
            `In: ${details?.promptTokens ?? "?"} | ` +
              `Out: ${details?.candidatesTokens ?? "?"} | ` +
              `Thoughts: ${details?.thoughtsTokens ?? "?"} | ` +
              `Total: ${details?.totalTokens ?? "?"} | ` +
              `${durSec}`,
          ),
          theme.fg(
            "dim",
            `Grounding Queries: ${details?.queriesUsed ?? 0} | ` +
              `Today: ${details?.dailyCount ?? 0}/${DEFAULT_DAILY_LIMIT} | ` +
              `Monthly Free: ${details?.queriesRemaining ?? 0}/5000`,
          ),
        ].join("\n");

        const fullText =
          "\n" +
          displayText
            .split("\n")
            .map((l) => theme.fg("success", l))
            .join("\n") +
          "\n\n" +
          footer;
        return new Text(fullText, 0, 0);
      },

      async execute(_toolCallId, params, signal, onUpdate) {
        const limit = isLimitExceeded();
        if (limit.exceeded && !params.query.includes("--force")) {
          return {
            content: [
              {
                type: "text" as const,
                text: `🛑 SEARCH BLOCKED: Hit your ${limit.reason}. Append '--force' to override.`,
              },
            ],
            details: { isError: true },
          };
        }
        try {
          const cleanQuery = params.query.replace("--force", "").trim();
          const level = levelFor(tool.depth);

          onUpdate?.({
            content: [
              {
                type: "text",
                text: `Searching: "${cleanQuery.slice(0, 80)}"...`,
              },
            ],
          });

          const r = await runSearch(cleanQuery, tool.depth, signal, onUpdate);
          return {
            content: [{ type: "text" as const, text: r.answer }],
            details: {
              model: level.model,
              depth: tool.depth,
              sourceCount: r.sourceCount,
              groundingQueries: r.groundingQueries,
              promptTokens: r.promptTokens,
              candidatesTokens: r.candidatesTokens,
              thoughtsTokens: r.thoughtsTokens,
              totalTokens: r.totalTokens,
              queriesUsed: r.queriesUsed,
              queriesRemaining: r.queriesRemaining,
              dailyCount: r.dailyCount,
              durationMs: r.durationMs,
            },
          };
        } catch (err) {
          return {
            content: [
              {
                type: "text" as const,
                text: err instanceof Error ? err.message : String(err),
              },
            ],
            details: { isError: true },
          };
        }
      },
    });
  }
}
